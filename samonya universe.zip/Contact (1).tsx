import React, { useState } from 'react';
import { useSEO } from '../services/seo';
import { Mail, MapPin, MessageCircle, CreditCard } from 'lucide-react';

export const Contact: React.FC = () => {
  useSEO("Contact Us", "Get in touch with Samonya Digital Universe.");
  const [sent, setSent] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSent(true);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-20">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-16">
        <div>
          <h1 className="text-4xl font-serif font-bold mb-6">Get in Touch</h1>
          <p className="text-gray-400 mb-8 text-lg">
            Have questions about our AI films, music licensing, or premium subscriptions? Reach out to our team.
          </p>
          
          <div className="space-y-6">
            <div className="flex items-center gap-4 group">
              <div className="bg-gray-800 p-3 rounded-full text-green-500 group-hover:bg-green-500 group-hover:text-white transition-colors"><MessageCircle className="h-6 w-6" /></div>
              <div>
                <h3 className="font-bold text-white">WhatsApp</h3>
                <a 
                  href="https://wa.me/254113558668" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-gray-400 hover:text-green-400 transition-colors"
                >
                  0113558668 (Chat with us)
                </a>
              </div>
            </div>

            <div className="flex items-center gap-4 group">
              <div className="bg-gray-800 p-3 rounded-full text-gold-500 group-hover:bg-gold-500 group-hover:text-black transition-colors"><Mail className="h-6 w-6" /></div>
              <div>
                <h3 className="font-bold text-white">Email</h3>
                <a href="mailto:samonyadigital@gmail.com" className="text-gray-400 hover:text-gold-500 transition-colors">
                  samonyadigital@gmail.com
                </a>
              </div>
            </div>

            <div className="flex items-center gap-4 group">
              <div className="bg-gray-800 p-3 rounded-full text-gold-500 group-hover:bg-gold-500 group-hover:text-black transition-colors"><CreditCard className="h-6 w-6" /></div>
              <div>
                <h3 className="font-bold text-white">Payments (M-Pesa)</h3>
                <p className="text-gray-400">Send to: <span className="text-white font-mono">0113558668</span></p>
              </div>
            </div>
            
            <div className="flex items-center gap-4 group">
              <div className="bg-gray-800 p-3 rounded-full text-gold-500 group-hover:bg-gold-500 group-hover:text-black transition-colors"><MapPin className="h-6 w-6" /></div>
              <div>
                <h3 className="font-bold text-white">HQ</h3>
                <p className="text-gray-400">Nairobi, Kenya</p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-gray-900 p-8 rounded-2xl border border-gray-800">
          {!sent ? (
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">Name</label>
                <input type="text" required className="w-full bg-black border border-gray-700 rounded-lg p-3 text-white focus:border-gold-500 focus:outline-none" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">Email</label>
                <input type="email" required className="w-full bg-black border border-gray-700 rounded-lg p-3 text-white focus:border-gold-500 focus:outline-none" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">Message</label>
                <textarea rows={4} required className="w-full bg-black border border-gray-700 rounded-lg p-3 text-white focus:border-gold-500 focus:outline-none"></textarea>
              </div>
              <button type="submit" className="w-full bg-gold-500 text-black font-bold py-3 rounded-lg hover:bg-gold-400 transition-colors">
                Send Message
              </button>
            </form>
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-center">
              <div className="bg-green-500/10 text-green-500 p-4 rounded-full mb-4">
                <Check className="h-8 w-8" />
              </div>
              <h3 className="text-2xl font-bold text-white mb-2">Message Sent!</h3>
              <p className="text-gray-400">We'll get back to you shortly.</p>
              <button onClick={() => setSent(false)} className="mt-6 text-gold-500 hover:text-white text-sm underline">Send another</button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// Simple check icon for the success state
const Check = ({ className }: { className?: string }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <polyline points="20 6 9 17 4 12" />
  </svg>
);
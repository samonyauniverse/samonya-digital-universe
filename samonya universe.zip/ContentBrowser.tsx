import React, { useState, useMemo } from 'react';
import { PlayCircle, Lock, Music, FileText, Film, ChevronLeft, ChevronRight } from 'lucide-react';
import { CONTENT_DATA } from '../constants';
import { BrandId } from '../types';

interface ContentBrowserProps {
  brandId?: BrandId; // Optional: if provided, filters by brand initially
  pageSize?: number;
}

const ALL_FILTER = 'All';

export const ContentBrowser: React.FC<ContentBrowserProps> = ({ brandId, pageSize = 6 }) => {
  const [selectedType, setSelectedType] = useState<string>(ALL_FILTER);
  const [selectedTag, setSelectedTag] = useState<string>(ALL_FILTER);
  const [currentPage, setCurrentPage] = useState(1);

  // Filter content based on brandId (if present), selectedType, and selectedTag
  const filteredContent = useMemo(() => {
    return CONTENT_DATA.filter(item => {
      // 1. Brand Filter
      if (brandId && item.category !== brandId) return false;
      
      // 2. Type Filter
      if (selectedType !== ALL_FILTER && item.type !== selectedType.toLowerCase()) return false;

      // 3. Tag Filter
      if (selectedTag !== ALL_FILTER && !item.tags?.includes(selectedTag.toLowerCase())) return false;

      return true;
    });
  }, [brandId, selectedType, selectedTag]);

  // Pagination Logic
  const totalPages = Math.ceil(filteredContent.length / pageSize);
  const paginatedContent = filteredContent.slice(
    (currentPage - 1) * pageSize,
    currentPage * pageSize
  );

  // Reset page when filters change
  React.useEffect(() => {
    setCurrentPage(1);
  }, [selectedType, selectedTag, brandId]);

  // Extract unique types and tags for the filter UI
  const availableTypes = useMemo(() => {
    const types = new Set(brandId 
      ? CONTENT_DATA.filter(c => c.category === brandId).map(c => c.type)
      : CONTENT_DATA.map(c => c.type)
    );
    return [ALL_FILTER, ...Array.from(types).map(t => t.charAt(0).toUpperCase() + t.slice(1))];
  }, [brandId]);

  const availableTags = useMemo(() => {
    const tags = new Set<string>();
    const baseData = brandId ? CONTENT_DATA.filter(c => c.category === brandId) : CONTENT_DATA;
    baseData.forEach(item => item.tags?.forEach(tag => tags.add(tag)));
    return [ALL_FILTER, ...Array.from(tags).sort()];
  }, [brandId]);

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'song': return <Music className="h-4 w-4" />;
      case 'article': return <FileText className="h-4 w-4" />;
      case 'film': return <Film className="h-4 w-4" />;
      default: return <PlayCircle className="h-4 w-4" />;
    }
  };

  return (
    <div className="w-full">
      {/* Filters Section */}
      <div className="mb-8 flex flex-col md:flex-row gap-6 justify-between items-start md:items-center bg-gray-900/50 p-6 rounded-xl border border-gray-800">
        
        {/* Type Filter */}
        <div className="w-full md:w-auto">
          <h3 className="text-xs font-bold text-gray-500 uppercase mb-3 tracking-wider">Content Type</h3>
          <div className="flex flex-wrap gap-2">
            {availableTypes.map(type => (
              <button
                key={type}
                onClick={() => setSelectedType(type)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                  selectedType === type
                    ? 'bg-gold-500 text-black shadow-lg shadow-gold-500/20'
                    : 'bg-gray-800 text-gray-400 hover:text-white hover:bg-gray-700'
                }`}
              >
                {type}
              </button>
            ))}
          </div>
        </div>

        {/* Tag Filter */}
        {availableTags.length > 2 && (
           <div className="w-full md:w-auto">
           <h3 className="text-xs font-bold text-gray-500 uppercase mb-3 tracking-wider">Categories & Tags</h3>
           <select 
             value={selectedTag}
             onChange={(e) => setSelectedTag(e.target.value)}
             className="bg-gray-800 text-white text-sm rounded-lg px-4 py-2 border border-gray-700 focus:border-gold-500 focus:outline-none w-full md:w-48"
           >
             {availableTags.map(tag => (
               <option key={tag} value={tag} className="capitalize">
                 {tag.charAt(0).toUpperCase() + tag.slice(1)}
               </option>
             ))}
           </select>
         </div>
        )}
      </div>

      {/* Content Grid */}
      {paginatedContent.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 animate-fade-in">
          {paginatedContent.map((item) => (
            <div key={item.id} className="bg-gray-900 rounded-lg overflow-hidden group hover:shadow-xl hover:shadow-gold-900/10 transition-all border border-gray-800 flex flex-col h-full">
              <div className="relative aspect-video overflow-hidden">
                <img 
                  src={item.thumbnail} 
                  alt={item.title} 
                  className="w-full h-full object-cover opacity-80 group-hover:opacity-100 group-hover:scale-110 transition-all duration-500" 
                />
                {item.premium && (
                  <div className="absolute top-2 right-2 bg-gold-500 text-black text-xs font-bold px-2 py-1 rounded flex items-center gap-1 z-10">
                    <Lock className="h-3 w-3" /> VIP
                  </div>
                )}
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/40 z-10">
                  <PlayCircle className="h-12 w-12 text-white drop-shadow-lg cursor-pointer transform hover:scale-110 transition-transform" />
                </div>
              </div>
              
              <div className="p-5 flex flex-col flex-grow">
                <div className="flex justify-between items-start mb-2">
                   <h3 className="font-bold text-white truncate pr-2 text-lg group-hover:text-gold-500 transition-colors">{item.title}</h3>
                </div>
                
                <div className="flex gap-2 mb-3 flex-wrap">
                  <span className="text-[10px] uppercase font-bold text-gray-400 border border-gray-700 px-2 py-0.5 rounded flex items-center gap-1">
                    {getTypeIcon(item.type)} {item.type}
                  </span>
                  {item.tags?.slice(0, 2).map(tag => (
                    <span key={tag} className="text-[10px] uppercase font-bold text-gold-600 bg-gold-500/10 px-2 py-0.5 rounded">
                      {tag}
                    </span>
                  ))}
                </div>

                <p className="text-sm text-gray-400 line-clamp-2 mb-4 flex-grow">{item.description}</p>
                
                <div className="flex items-center justify-between text-xs text-gray-500 pt-4 border-t border-gray-800 mt-auto">
                   <span>{item.duration || item.date}</span>
                   <button className="text-gold-500 hover:text-white font-medium transition-colors">View Details</button>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="py-20 text-center bg-gray-900/30 rounded-xl border border-dashed border-gray-800">
          <div className="text-gray-500 text-lg mb-2">No content found matching your filters.</div>
          <button 
            onClick={() => { setSelectedType(ALL_FILTER); setSelectedTag(ALL_FILTER); }}
            className="text-gold-500 hover:text-white text-sm font-semibold"
          >
            Clear Filters
          </button>
        </div>
      )}

      {/* Pagination Controls */}
      {totalPages > 1 && (
        <div className="mt-12 flex justify-center items-center gap-4">
          <button
            onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
            disabled={currentPage === 1}
            className="p-2 rounded-full border border-gray-700 text-gray-400 hover:text-white hover:border-gold-500 disabled:opacity-30 disabled:hover:border-gray-700 disabled:hover:text-gray-400 transition-all"
          >
            <ChevronLeft className="h-5 w-5" />
          </button>
          
          <div className="flex gap-2">
            {Array.from({ length: totalPages }, (_, i) => i + 1).map(page => (
              <button
                key={page}
                onClick={() => setCurrentPage(page)}
                className={`w-8 h-8 rounded-full text-sm font-bold transition-all ${
                  currentPage === page
                    ? 'bg-gold-500 text-black'
                    : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
                }`}
              >
                {page}
              </button>
            ))}
          </div>

          <button
            onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
            disabled={currentPage === totalPages}
            className="p-2 rounded-full border border-gray-700 text-gray-400 hover:text-white hover:border-gold-500 disabled:opacity-30 disabled:hover:border-gray-700 disabled:hover:text-gray-400 transition-all"
          >
            <ChevronRight className="h-5 w-5" />
          </button>
        </div>
      )}
    
import { GoogleGenAI } from "@google/genai";
import { BRANDS, CONTENT_DATA } from '../constants';

const API_KEY = process.env.API_KEY || ''; // In a real app, ensure this is set securely.

// Provide context about the website to the model
const SYSTEM_INSTRUCTION = `
You are the AI Assistant for "Samonya Digital Universe", a digital media ecosystem.
Your tone is helpful, futuristic, and enthusiastic.
The ecosystem includes:
${BRANDS.map(b => `- ${b.name}: ${b.description}`).join('\n')}

Here is some sample content available on the platform:
${CONTENT_DATA.map(c => `- ${c.title} (${c.type}) in ${c.category}`).join('\n')}

Help users navigate, recommend content, and explain the pricing tiers.
Keep responses concise (under 100 words) unless asked for more detail.
`;

export const getGeminiResponse = async (userMessage: string): Promise<string> => {
  if (!API_KEY) {
    return "I'm currently offline (API Key missing). Please contact the administrator.";
  }

  try {
    const ai = new GoogleGenAI({ apiKey: API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: userMessage,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
      }
    });
    
    return response.text || "I didn't catch that. Could you try asking about our movies or music?";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "I'm having trouble connecting to the Samonya Mainframe. Please try again later.";
  }
};
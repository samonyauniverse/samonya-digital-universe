import React, { useState } from 'react';
import { useSEO } from '../services/seo';

export const Auth: React.FC = () => {
  const [isLogin, setIsLogin] = useState(true);
  useSEO(isLogin ? "Sign In" : "Sign Up", "Access your Samonya account.");

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4">
      <div className="w-full max-w-md bg-gray-900 border border-gray-800 rounded-2xl p-8 shadow-2xl">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-serif font-bold text-white mb-2">{isLogin ? 'Welcome Back' : 'Join the Universe'}</h1>
          <p className="text-gray-400 text-sm">
            {isLogin ? 'Enter your credentials to access your content.' : 'Start your journey with a free account.'}
          </p>
        </div>

        <form className="space-y-4">
          {!isLogin && (
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Full Name</label>
              <input type="text" className="w-full bg-black border border-gray-700 rounded-lg p-3 text-white focus:border-gold-500 focus:outline-none" placeholder="John Doe" />
            </div>
          )}
          <div>
            <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Email Address</label>
            <input type="email" className="w-full bg-black border border-gray-700 rounded-lg p-3 text-white focus:border-gold-500 focus:outline-none" placeholder="you@example.com" />
          </div>
          <div>
            <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Password</label>
            <input type="password" className="w-full bg-black border border-gray-700 rounded-lg p-3 text-white focus:border-gold-500 focus:outline-none" placeholder="••••••••" />
          </div>

          <button type="button" className="w-full bg-gold-500 hover:bg-gold-400 text-black font-bold py-3 rounded-lg transition-colors mt-6">
            {isLogin ? 'Sign In' : 'Create Account'}
          </button>
        </form>

        <div className="mt-6 text-center text-sm">
          <span className="text-gray-400">{isLogin ? "Don't have an account? " : "Already have an account? "}</span>
          <button onClick={() => setIsLogin(!isLogin)} className="text-gold-500 hover:text-white font-semibold">
            {isLogin ? 'Sign Up' : 'Log In'}
          </button>
        </div>

        <div className="mt-8 pt-6 border-t border-gray-800 text-center">
          <p className="text-xs text-gray-500 mb-4">Or continue with</p>
          <div className="flex gap-4 justify-center">
             <button className="bg-white text-black px-4 py-2 rounded flex items-center gap-2 text-sm font-bold hover:bg-gray-200">Google</button>
             <button className="bg-[#1877F2] text-white px-4 py-2 rounded flex items-center gap-2 text-sm font-bold hover:bg-[#166fe5]">Facebook</button>
          </div>
        </div>
      </div>
    </div>
  );
};
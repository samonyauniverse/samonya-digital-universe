import React from 'react';
import { BLOG_POSTS } from '../constants';
import { useSEO } from '../services/seo';

export const Blog: React.FC = () => {
  useSEO("Blog & News", "Latest updates from Samonya Digital Universe.");

  return (
    <div className="max-w-5xl mx-auto px-4 py-16">
      <h1 className="text-4xl font-serif font-bold mb-12 border-l-4 border-gold-500 pl-4">Latest Insights</h1>
      
      <div className="space-y-12">
        {BLOG_POSTS.map((post) => (
          <article key={post.id} className="flex flex-col md:flex-row gap-8 items-start pb-12 border-b border-gray-800 last:border-0">
            <div className="w-full md:w-1/3 aspect-[4/3] rounded-lg overflow-hidden bg-gray-800">
              <img src={post.image} alt={post.title} className="w-full h-full object-cover hover:scale-105 transition-transform duration-500" />
            </div>
            <div className="flex-1">
              <div className="flex gap-2 mb-3">
                {post.tags.map(tag => (
                  <span key={tag} className="text-xs font-bold text-gold-500 uppercase tracking-wider">{tag}</span>
                ))}
              </div>
              <h2 className="text-2xl font-bold text-white mb-3 hover:text-gold-400 cursor-pointer">{post.title}</h2>
              <p className="text-gray-400 mb-4 line-clamp-2">{post.excerpt}</p>
              <div className="flex items-center justify-between mt-auto">
                 <div className="text-sm text-gray-500">
                    By <span className="text-gray-300">{post.author}</span> • {post.date}
                 </div>
                 <button className="text-sm font-semibold text-white border-b border-gold-500 pb-0.5 hover:text-gold-500 transition-colors">Read Article</button>
              </div>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
};
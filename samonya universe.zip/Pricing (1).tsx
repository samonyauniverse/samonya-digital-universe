import React from 'react';
import { Check } from 'lucide-react';
import { PRICING_TIERS } from '../constants';
import { useSEO } from '../services/seo';

export const Pricing: React.FC = () => {
  useSEO("Pricing", "Choose your membership plan for Samonya Digital Universe");

  return (
    <div className="py-20 px-4 max-w-7xl mx-auto">
      <div className="text-center mb-16">
        <h1 className="text-4xl md:text-5xl font-serif font-bold mb-4">Unlock the Full Universe</h1>
        <p className="text-gray-400 max-w-2xl mx-auto">
          Support independent digital creators and get exclusive access to premium AI content, offline downloads, and high-fidelity streaming.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
        {PRICING_TIERS.map((tier) => (
          <div key={tier.id} className={`relative bg-gray-900 rounded-2xl p-8 border ${tier.recommended ? 'border-gold-500 ring-1 ring-gold-500' : 'border-gray-800'} flex flex-col`}>
            {tier.recommended && (
              <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 bg-gold-500 text-black px-4 py-1 rounded-full text-xs font-bold uppercase tracking-wide">
                Most Popular
              </div>
            )}
            <h3 className="text-xl font-bold text-white mb-2">{tier.name}</h3>
            <div className="mb-6">
              <span className="text-4xl font-serif font-bold text-white">{tier.price}</span>
            </div>
            <ul className="space-y-4 mb-8 flex-grow">
              {tier.features.map((feat, i) => (
                <li key={i} className="flex items-start gap-3 text-sm text-gray-300">
                  <Check className="h-5 w-5 text-gold-500 shrink-0" />
                  {feat}
                </li>
              ))}
            </ul>
            <button className={`w-full py-3 rounded-lg font-bold transition-colors ${
              tier.recommended 
                ? 'bg-gold-500 text-black hover:bg-gold-400' 
                : 'bg-gray-800 text-white hover:bg-gray-700'
            }`}>
              Choose Plan
            </button>
          </div>
        ))}
      </div>
      
      <div className="mt-20 text-center bg-gray-900/50 p-8 rounded-xl border border-gray-800 max-w-3xl mx-auto">
        <h3 className="text-white font-bold mb-4">Payment Information</h3>
        <p className="text-sm text-gray-400 leading-relaxed">
          <span className="block mb-2 text-white">M-Pesa Payment Number: <span className="font-mono text-gold-500 text-lg">0113558668</span></span>
          Accepted Payment Methods: M-Pesa, PayPal, Visa, MasterCard.
          <br />
          Cancel anytime from your user account settings.
        </p>
      </div>
    </div>
  );
};
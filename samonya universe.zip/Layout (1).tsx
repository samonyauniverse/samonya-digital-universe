import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Globe, User, Search } from 'lucide-react';
import { BRANDS } from '../constants';
import { GeminiChat } from './GeminiChat';

export const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path ? 'text-gold-500' : 'text-gray-300 hover:text-white';

  return (
    <div className="min-h-screen flex flex-col bg-samonya-black text-white relative overflow-x-hidden">
      {/* Navbar */}
      <nav className="fixed w-full z-50 bg-samonya-black/90 backdrop-blur-md border-b border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            {/* Logo */}
            <div className="flex-shrink-0">
              <Link to="/" className="flex items-center gap-2">
                <Globe className="h-8 w-8 text-gold-500" />
                <span className="font-serif font-bold text-xl tracking-wider text-white">SAMONYA</span>
              </Link>
            </div>

            {/* Desktop Menu */}
            <div className="hidden md:block">
              <div className="ml-10 flex items-baseline space-x-8">
                <Link to="/" className={`${isActive('/')} px-3 py-2 rounded-md text-sm font-medium transition-colors`}>Home</Link>
                {BRANDS.map((brand) => (
                  <Link key={brand.id} to={brand.path} className={`${isActive(brand.path)} px-3 py-2 rounded-md text-sm font-medium transition-colors uppercase`}>
                    {brand.name.split(' ')[1]}
                  </Link>
                ))}
                <Link to="/pricing" className={`${isActive('/pricing')} px-3 py-2 rounded-md text-sm font-medium transition-colors`}>Pricing</Link>
              </div>
            </div>

            {/* Desktop Icons */}
            <div className="hidden md:flex items-center gap-4">
               <Link to="/search" className="text-gray-400 hover:text-white"><Search className="h-5 w-5" /></Link>
               <Link to="/auth" className="flex items-center gap-2 bg-gold-600 hover:bg-gold-500 text-black px-4 py-2 rounded-full font-bold text-sm transition-all">
                 <User className="h-4 w-4" /> Account
               </Link>
            </div>

            {/* Mobile menu button */}
            <div className="-mr-2 flex md:hidden">
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="bg-gray-900 inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-white hover:bg-gray-800 focus:outline-none"
              >
                {isMenuOpen ? <X className="block h-6 w-6" /> : <Menu className="block h-6 w-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden bg-gray-900 border-b border-gray-800">
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
              <Link to="/" onClick={() => setIsMenuOpen(false)} className="text-gray-300 hover:text-white block px-3 py-2 rounded-md text-base font-medium">Home</Link>
              {BRANDS.map((brand) => (
                <Link key={brand.id} to={brand.path} onClick={() => setIsMenuOpen(false)} className="text-gray-300 hover:text-white block px-3 py-2 rounded-md text-base font-medium">
                  {brand.name}
                </Link>
              ))}
              <Link to="/pricing" onClick={() => setIsMenuOpen(false)} className="text-gray-300 hover:text-white block px-3 py-2 rounded-md text-base font-medium">Pricing</Link>
              <Link to="/auth" onClick={() => setIsMenuOpen(false)} className="text-gold-500 font-bold block px-3 py-2 rounded-md text-base">Sign In</Link>
            </div>
          </div>
        )}
      </nav>

      {/* Main Content */}
      <main className="flex-grow pt-20">
        {children}
      </main>

      {/* AI Assistant */}
      <GeminiChat />

      {/* Footer */}
      <footer className="bg-black border-t border-gray-900 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center gap-2 mb-4">
                <Globe className="h-6 w-6 text-gold-500" />
                <span className="font-serif font-bold text-lg text-white">SAMONYA DIGITAL</span>
              </div>
              <p className="text-gray-400 text-sm max-w-sm">
                The ultimate ecosystem for next-gen entertainment. From AI-generated melodies to educational adventures and cinematic masterpieces.
              </p>
            </div>
            <div>
              <h3 className="text-white font-semibold mb-4 uppercase tracking-wider text-sm">Brands</h3>
              <ul className="space-y-2">
                {BRANDS.map(b => (
                  <li key={b.id}><Link to={b.path} className="text-gray-400 hover:text-gold-500 text-sm transition-colors">{b.name}</Link></li>
                ))}
              </ul>
            </div>
            <div>
              <h3 className="text-white font-semibold mb-4 uppercase tracking-wider text-sm">Support</h3>
              <ul className="space-y-2">
                <li><Link to="/contact" className="text-gray-400 hover:text-gold-500 text-sm">Contact Us</Link></li>
                <li><Link to="/pricing" className="text-gray-400 hover:text-gold-500 text-sm">Membership</Link></li>
                <li><Link to="/blog" className="text-gray-400 hover:text-gold-500 text-sm">Blog & News</Link></li>
                <li><span className="text-gray-600 text-sm cursor-not-allowed">Privacy Policy</span></li>
              </ul>
            </div>
          </div>
          <div className="mt-12 pt-8 border-t border-gray-900 text-center text-gray-500 text-sm">
            &copy; {new Date().getFullYear()} Samonya Digital Universe. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
};
import React from 'react';
import { BRANDS } from '../constants';
import { useSEO } from '../services/seo';
import { BrandId } from '../types';
import { ContentBrowser } from '../components/ContentBrowser';

interface BrandPageProps {
  brandId: BrandId;
}

export const BrandPage: React.FC<BrandPageProps> = ({ brandId }) => {
  const brand = BRANDS.find(b => b.id === brandId);

  useSEO(brand?.name || 'Brand', brand?.description || '');

  if (!brand) return <div>Brand not found</div>;

  return (
    <div>
      {/* Brand Hero */}
      <div className="bg-gradient-to-r from-gray-900 via-gray-800 to-black py-20 px-4 border-b border-gray-800 relative overflow-hidden">
        {/* Abstract Background Element */}
        <div className={`absolute top-0 right-0 w-96 h-96 opacity-10 blur-3xl rounded-full translate-x-1/3 -translate-y-1/3 pointer-events-none ${brand.color.replace('text-', 'bg-')}`}></div>
        
        <div className="max-w-7xl mx-auto relative z-10">
          <span className={`text-sm font-bold tracking-widest uppercase mb-3 block ${brand.color}`}>{brand.tagline}</span>
          <h1 className="text-5xl md:text-7xl font-serif font-bold text-white mb-6 animate-fade-in">{brand.name}</h1>
          <p className="text-xl text-gray-300 max-w-2xl font-light leading-relaxed">{brand.description}</p>
        </div>
      </div>

      {/* Content Browser Section */}
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-2xl font-bold text-white">Featured Content</h2>
        </div>
        
        {/* Dynamic Filterable Content Grid */}
        <ContentBrowser brandId={brandId} pageSize={6} />
        
      </div>
    </div>
  );
};
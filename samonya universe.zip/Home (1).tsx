import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Play, Film, Music, Tv, Smile } from 'lucide-react';
import { BRANDS } from '../constants';
import { useSEO } from '../services/seo';
import { ContentBrowser } from '../components/ContentBrowser';

export const Home: React.FC = () => {
  useSEO("Home", "Welcome to Samonya Digital Universe - The future of entertainment.");

  const getIcon = (id: string) => {
    switch(id) {
      case 'samn-milele': return <Music className="h-8 w-8" />;
      case 'samonya-kids': return <Smile className="h-8 w-8" />;
      case 'samn-sky': return <Music className="h-8 w-8" />;
      case 'samonya-tv': return <Tv className="h-8 w-8" />;
      case 'samonya-films': return <Film className="h-8 w-8" />;
      default: return <Play className="h-8 w-8" />;
    }
  };

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative h-[80vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-samonya-black z-10"></div>
        <div className="absolute inset-0 z-0">
          <img 
            src="https://picsum.photos/1920/1080?grayscale&blur=2" 
            alt="Samonya Universe" 
            className="w-full h-full object-cover opacity-40"
          />
        </div>
        <div className="relative z-20 text-center px-4 max-w-4xl mx-auto">
          <h1 className="text-5xl md:text-7xl font-serif font-bold text-white mb-6 animate-fade-in">
            WELCOME TO THE <span className="text-gold-500">UNIVERSE</span>
          </h1>
          <p className="text-xl md:text-2xl text-gray-300 mb-10 font-light">
            Where AI innovation meets human creativity. Music, Films, Kids Content & News all in one place.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link to="/auth" className="bg-gold-500 hover:bg-gold-400 text-black px-8 py-3 rounded-full font-bold transition-transform hover:scale-105">
              Join the Universe
            </Link>
            <Link to="/about" className="bg-transparent border border-white text-white hover:bg-white hover:text-black px-8 py-3 rounded-full font-bold transition-colors">
              Learn More
            </Link>
          </div>
        </div>
      </section>

      {/* Brands Grid */}
      <section className="py-20 px-4 md:px-8 max-w-7xl mx-auto">
        <h2 className="text-3xl font-serif font-bold text-center mb-16">Explore Our Worlds</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {BRANDS.map((brand) => (
            <Link key={brand.id} to={brand.path} className="group relative bg-gray-900 rounded-xl overflow-hidden border border-gray-800 hover:border-gold-600 transition-all duration-300 hover:shadow-2xl hover:shadow-gold-900/20">
              <div className="h-48 overflow-hidden">
                <div className={`w-full h-full bg-gradient-to-br from-gray-800 to-black group-hover:scale-105 transition-transform duration-500 flex items-center justify-center ${brand.color}`}>
                   {getIcon(brand.id)}
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold text-white mb-2">{brand.name}</h3>
                <p className="text-sm text-gold-500 font-semibold mb-3 uppercase tracking-wider">{brand.tagline}</p>
                <p className="text-gray-400 text-sm mb-4">{brand.description}</p>
                <div className="flex items-center text-gold-400 font-medium text-sm group-hover:translate-x-2 transition-transform">
                  Enter World <ArrowRight className="ml-2 h-4 w-4" />
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* NEW: Universal Content Browser */}
      <section className="bg-samonya-black py-20 px-4 md:px-8 max-w-7xl mx-auto border-t border-gray-900">
         <div className="text-center mb-12">
            <h2 className="text-3xl font-serif font-bold text-white mb-4">Latest from the Universe</h2>
            <p className="text-gray-400">Discover trending music, videos, and stories across all brands.</p>
         </div>
         <ContentBrowser pageSize={6} />
      </section>

      {/* CTA Section */}
      <section className="bg-gold-600 text-black py-20 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-serif font-bold mb-6">Ready for Premium Entertainment?</h2>
          <p className="text-lg mb-8 opacity-90">Unlock exclusive AI films, ad-free music, and premium educational content for your kids.</p>
          <Link to="/pricing" className="inline-block bg-black text-white px-10 py-4 rounded-full font-bold text-lg hover:bg-gray-900 transition-colors">
            View Membership Plans
          </Link>
        </div>
      </section>
    </div>
  );
};